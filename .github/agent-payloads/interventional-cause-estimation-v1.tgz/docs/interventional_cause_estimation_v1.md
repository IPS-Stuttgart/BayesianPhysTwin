# Quantitative interventional cause estimation and intervention design v1

## Scientific question

`interventional_cause_identifiability_v1` answers whether a registered physical-
twin error cause is distinguishable from every competing cause under a finite
intervention roster. This extension answers the two questions required for an
operational diagnosis:

1. how accurately can the supported cause-specific quantity be estimated; and
2. what is the lowest-cost intervention portfolio that makes every required
   diagnosis identifiable with bounded noise amplification?

The candidate error causes remain a preregistered finite family. Typical members
are physical-state error, material-parameter error, realized contact error,
observation bias, and source-local discrepancy.

## Model

For one cause `c`, stack the whitened observations from the selected interventions:

\[
r = S_c\beta_c + C_c\gamma_c + \epsilon,
\]

where `C_c` concatenates every competing cause signature and every declared
nuisance direction. Let

\[
P_c=I-C_cC_c^\dagger,
\qquad
A_c=P_cS_c,
\]

and let the registered cause query be

\[
q_c=B_c\beta_c.
\]

The binary certificate establishes estimability when

\[
\ker(A_c)\subseteq\ker(B_c).
\]

Equivalently, `B_c = M_c A_c` for at least one linear map `M_c`.

## Theorem 1: minimum-variance linear unbiased cause-query estimate

Assume the registered whitened model has

\[
\mathbb E[\epsilon]=0,
\qquad
\operatorname{Cov}(\epsilon)=\sigma^2 I.
\]

When the cause query is estimable, define

\[
\widehat q_c
 = B_cA_c^\dagger P_cr.
\]

Then `qhat_c` is unbiased for `q_c`. Among all linear unbiased estimators of the
registered query, it has minimum covariance, with

\[
\operatorname{Cov}(\widehat q_c)
 = \sigma^2L_cL_c^\top,
\qquad
L_c=B_cA_c^\dagger P_c.
\]

### Proof

Estimability gives `B_c=B_cA_c^dagger A_c`. Because `P_c C_c=0`,

\[
\mathbb E[\widehat q_c]
 = B_cA_c^\dagger P_cS_c\beta_c
 = B_cA_c^\dagger A_c\beta_c
 = B_c\beta_c.
\]

After projection, the noise is isotropic on the range of `P_c`, and the columns
of `A_c` lie in that range. The ordinary Gauss--Markov theorem on this reduced
space therefore gives the stated BLUE and covariance. The implementation
returns the supported projection and explicitly marks it nonidentifiable when
the full query fails the kernel-inclusion test; that projection must not be
relabeled as the complete physical cause.

## Corollary: deterministic finite-noise bound

For any projected disturbance satisfying

\[
\|P_c\epsilon\|_2\le\rho,
\]

the query error satisfies

\[
\|\widehat q_c-q_c\|_2
\le
\rho\,\|L_c\|_2.
\]

The spectral factor `||L_c||_2` is reported as the query noise gain. For the full
cause coefficient (`B_c=I`) and a full-column-rank residualized signature, this
reduces to

\[
\|\widehat\beta_c-\beta_c\|_2
\le
\frac{\rho}{\sigma_{\min}(A_c)}.
\]

Thus identifiability alone is not sufficient: a cause can be theoretically
identifiable but too poorly separated for a stable physical interpretation.

## Exact finite-roster intervention design

For a frozen intervention roster `U`, nonnegative costs `c(u)`, required causes
`C_req`, a cost budget `C_max`, and a maximum query noise gain `G_max`, a
portfolio `V subseteq U` is feasible when every required query is identifiable
and

\[
\sum_{u\in V}c(u)\le C_{\max},
\qquad
\max_{c\in C_{req}}\|L_{c,V}\|_2\le G_{\max}.
\]

The implementation enumerates the complete finite roster and returns the exact
lexicographic optimum:

1. minimum total intervention cost;
2. minimum worst query noise gain;
3. minimum number of interventions; and
4. canonical intervention identity.

This is an exact result for the registered finite roster, not a claim about an
unbounded continuous intervention space.

## Controlled falsification result

The controlled study retains the five-cause construction from the binary
certificate. All causes share the same response under the factual source action;
changed interventions separate them. Intervention costs are `(0, 1, 1, 3)`.
The exact design selects the factual action plus two diagnostic actions, leaving
the most expensive action for held-intervention scoring.

For 10,000 frozen trials with Gaussian whitened noise of standard deviation
`0.05`:

| Method | Cause-query RMSE | Held-intervention RMSE |
| --- | ---: | ---: |
| Factual action / minimum norm | 0.931761 | 1.129667 |
| Exact selected portfolio | 0.080491 | 0.052733 |
| All interventions | 0.058082 | 0.034834 |
| Wrong-action relation | 1.384018 | 1.942987 |

The selected portfolio costs `2`, versus `5` for all interventions, while its
nominal-90% cause-query coverage is `89.752%`. A noiseless registered query is
recovered to floating-point precision. Declaring a nuisance exactly aligned
with the material signature correctly changes the material query to
nonidentifiable.

The controlled result demonstrates that the binary certificate can be turned
into a calibrated estimate and a cost-aware diagnostic design. It is not real-
object evidence.

## Intended real-data continuation

The public Tracking Cloth self-collision factorial is the immediate source-side
candidate. Repetition 1 can fit response signatures, repetition 2 can freeze the
cause roster and diagnostic intervention portfolio, and repetition 3 can be
scored only after all cause estimates and held-intervention predictions are
jointly sealed. A natural physical-cause interpretation additionally requires:

- stable response signatures across source repetitions;
- nonlinear replay closure;
- held-intervention transport;
- separation from wrong-intervention, wrong-material, temporal-shift, and
  marker-identity controls; and
- exact fallback for unresolved causes.

A source or confirmation failure is a scientific negative. It must not be
rescued through post-outcome changes to the cause family, nuisance design,
intervention costs, or thresholds.

## Claim boundary

A returned estimate is valid only under the exact supplied local response
signatures, finite cause family, nuisance model, whitening, intervention subset,
and noise model. The intervention portfolio is optimal only in the frozen finite
roster and cost model. Neither artifact proves that the cause family is complete,
that a cause label is the unique data-generating mechanism, that the signatures
are physically correct, or that the result transfers to unseen objects,
nonlinear regimes, online control, deployment, or safety-critical use.
