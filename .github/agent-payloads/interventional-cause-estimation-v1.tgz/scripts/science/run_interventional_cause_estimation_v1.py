#!/usr/bin/env python3
"""Controlled estimation and intervention-design study for error attribution."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np

from bayesian_phystwin_experiments.interventional_cause_estimation_v1 import (
    estimate_interventional_causes,
    select_intervention_portfolio,
)
from bayesian_phystwin_experiments.interventional_cause_identifiability_v1 import (
    CauseResponseSignatureV1,
    InterventionalCauseIdentifiabilityCertificateV1,
    InterventionResponseBlockV1,
)

SHA = "a" * 64
CAUSES = (
    "observation_bias",
    "physical_parameter",
    "physical_state",
    "realized_intervention",
    "source_local_discrepancy",
)
ACTIONS = ("action-0", "action-1", "action-2", "action-3")
ACTION_COSTS = {
    "action-0": 0.0,
    "action-1": 1.0,
    "action-2": 1.0,
    "action-3": 3.0,
}


def response_columns() -> dict[str, np.ndarray]:
    return {
        "observation_bias": np.asarray([[1.0, 0.0, 0.0]] * 4),
        "physical_parameter": np.asarray(
            [
                [1.0, 0.0, 0.0],
                [0.0, 1.0, 0.2],
                [0.2, 0.3, 1.0],
                [0.5, 1.0, -0.3],
            ]
        ),
        "physical_state": np.asarray(
            [
                [1.0, 0.0, 0.0],
                [1.0, 0.5, 0.0],
                [1.0, -0.5, 0.5],
                [1.0, 0.2, -0.6],
            ]
        ),
        "realized_intervention": np.asarray(
            [
                [1.0, 0.0, 0.0],
                [0.5, -0.5, 1.0],
                [-0.5, 1.0, 0.1],
                [1.0, -1.0, 0.5],
            ]
        ),
        "source_local_discrepancy": np.asarray(
            [
                [1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
            ]
        ),
    }


def _cause(
    cause_id: str,
    values: np.ndarray,
) -> CauseResponseSignatureV1:
    return CauseResponseSignatureV1(
        cause_id=cause_id,
        latent_coordinates_id=SHA,
        cause_query_id=SHA,
        intervention_blocks=tuple(
            InterventionResponseBlockV1(
                intervention_id=action,
                response_signature_id=SHA,
                whitened_response_signature=values[index, :, None],
            )
            for index, action in enumerate(ACTIONS)
        ),
        cause_query_map=np.eye(1),
    )


def certificate(
    *,
    nuisance: np.ndarray | None = None,
) -> InterventionalCauseIdentifiabilityCertificateV1:
    columns = response_columns()
    if nuisance is None:
        nuisance = np.empty((12, 0), dtype=np.float64)
    return InterventionalCauseIdentifiabilityCertificateV1(
        observation_whitening_id=SHA,
        declared_nuisance_id=SHA,
        cause_family_id=SHA,
        cause_signatures=tuple(_cause(cause, columns[cause]) for cause in CAUSES),
        joint_whitened_nuisance_design=nuisance,
        metadata={"study": "why-is-the-twin-wrong-estimation-v1"},
    )


def _canonical_id(value: dict[str, Any]) -> str:
    encoded = json.dumps(
        value,
        allow_nan=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _rows_for(actions: tuple[str, ...]) -> np.ndarray:
    indices: list[int] = []
    for action in actions:
        offset = 3 * ACTIONS.index(action)
        indices.extend(range(offset, offset + 3))
    return np.asarray(indices, dtype=int)


def _metrics(
    estimates: np.ndarray,
    truth: np.ndarray,
    design: np.ndarray,
    held_rows: np.ndarray,
) -> dict[str, float]:
    coefficient_rmse = float(np.sqrt(np.mean((estimates - truth) ** 2)))
    prediction = estimates @ design[held_rows].T
    target = truth @ design[held_rows].T
    held_rmse = float(np.sqrt(np.mean((prediction - target) ** 2)))
    return {
        "cause_query_rmse": coefficient_rmse,
        "held_intervention_rmse": held_rmse,
    }


def run(
    *,
    replicates: int,
    seed: int,
    noise_standard_deviation: float,
) -> dict[str, Any]:
    if replicates < 100:
        raise ValueError("replicates must be at least 100")
    if not np.isfinite(noise_standard_deviation) or noise_standard_deviation <= 0:
        raise ValueError("noise_standard_deviation must be positive")

    cert = certificate()
    portfolio = select_intervention_portfolio(
        cert,
        ACTION_COSTS,
        mandatory_intervention_ids=("action-0",),
        maximum_query_noise_gain=5.0,
        metadata={"selection": "exact-minimum-cost-stable"},
    )
    if portfolio.selected is None:
        raise RuntimeError("registered intervention portfolio is infeasible")
    selected_actions = portfolio.selected.intervention_ids
    selected_rows = _rows_for(selected_actions)
    source_rows = _rows_for(("action-0",))
    all_rows = _rows_for(ACTIONS)
    held_actions = tuple(action for action in ACTIONS if action not in selected_actions)
    held_rows = _rows_for(held_actions)
    if held_actions != ("action-3",):
        raise RuntimeError("registered design no longer leaves action-3 held out")

    columns = response_columns()
    design = np.column_stack([columns[cause].reshape(-1) for cause in CAUSES])
    wrong_columns = {
        cause: values[np.asarray((0, 2, 1, 3))]
        for cause, values in columns.items()
    }
    wrong_design = np.column_stack(
        [wrong_columns[cause].reshape(-1) for cause in CAUSES]
    )

    source_operator = np.linalg.pinv(design[source_rows])
    selected_operator = np.linalg.pinv(design[selected_rows])
    all_operator = np.linalg.pinv(design[all_rows])
    wrong_operator = np.linalg.pinv(wrong_design[selected_rows])

    rng = np.random.default_rng(seed)
    amplitudes = rng.uniform(0.5, 1.5, size=(replicates, len(CAUSES)))
    signs = rng.choice(np.asarray([-1.0, 1.0]), size=amplitudes.shape)
    truth = amplitudes * signs
    noiseless = truth @ design.T
    observed = noiseless + rng.normal(
        0.0,
        noise_standard_deviation,
        size=noiseless.shape,
    )

    estimates = {
        "source_action_minimum_norm": (
            observed[:, source_rows] @ source_operator.T
        ),
        "selected_intervention_portfolio": (
            observed[:, selected_rows] @ selected_operator.T
        ),
        "all_interventions": observed[:, all_rows] @ all_operator.T,
        "wrong_action_relation": observed[:, selected_rows] @ wrong_operator.T,
    }
    metrics = {
        name: _metrics(values, truth, design, held_rows)
        for name, values in estimates.items()
    }

    selected_covariance = (
        noise_standard_deviation**2
        * selected_operator
        @ selected_operator.T
    )
    standard_deviation = np.sqrt(np.diag(selected_covariance))
    covered = np.abs(estimates["selected_intervention_portfolio"] - truth) <= (
        1.6448536269514722 * standard_deviation[None, :]
    )
    coverage = float(np.mean(covered))
    per_cause_coverage = {
        cause: float(np.mean(covered[:, index]))
        for index, cause in enumerate(CAUSES)
    }

    deterministic_truth = {
        cause: 0.2 * (index + 1) for index, cause in enumerate(CAUSES)
    }
    deterministic_residual = sum(
        deterministic_truth[cause] * columns[cause].reshape(-1)
        for cause in CAUSES
    )
    exact_estimate = estimate_interventional_causes(
        cert,
        deterministic_residual,
        intervention_ids=selected_actions,
        noise_variance=noise_standard_deviation**2,
        noise_radius=2.0 * noise_standard_deviation,
    )
    exact_recovery_error = max(
        abs(
            float(exact_estimate.result_for(cause).query_mean[0])
            - deterministic_truth[cause]
        )
        for cause in CAUSES
    )

    material_signature = columns["physical_parameter"].reshape(-1, 1)
    confounded = certificate(nuisance=material_signature)
    confounded_estimate = estimate_interventional_causes(
        confounded,
        deterministic_residual,
        noise_variance=noise_standard_deviation**2,
    ).result_for("physical_parameter")

    selected_metric = metrics["selected_intervention_portfolio"]
    all_metric = metrics["all_interventions"]
    source_metric = metrics["source_action_minimum_norm"]
    wrong_metric = metrics["wrong_action_relation"]
    source_estimate = estimate_interventional_causes(
        cert,
        deterministic_residual,
        intervention_ids=("action-0",),
        noise_variance=noise_standard_deviation**2,
    )
    checks = {
        "source_action_confounded": not source_estimate.all_queries_identifiable,
        "selected_portfolio_uses_three_actions": len(selected_actions) == 3,
        "selected_portfolio_cost_below_all_actions": (
            portfolio.selected.total_cost < sum(ACTION_COSTS.values())
        ),
        "selected_query_rmse_near_all_interventions": (
            selected_metric["cause_query_rmse"]
            <= 1.5 * all_metric["cause_query_rmse"]
        ),
        "selected_held_rmse_below_source_by_80_percent": (
            selected_metric["held_intervention_rmse"]
            <= 0.2 * source_metric["held_intervention_rmse"]
        ),
        "wrong_relation_degrades_held_prediction": (
            wrong_metric["held_intervention_rmse"]
            >= 5.0 * selected_metric["held_intervention_rmse"]
        ),
        "selected_90_coverage_in_registered_band": 0.88 <= coverage <= 0.92,
        "noiseless_registered_queries_recovered": exact_recovery_error <= 1e-10,
        "declared_aligned_nuisance_forces_confounding": (
            not confounded_estimate.query_identifiable
            and confounded_estimate.residualized_cause_rank == 0
        ),
    }
    passed = all(checks.values())
    result: dict[str, Any] = {
        "schema": "bayesian-phystwin.interventional-cause-estimation-study.v1",
        "schema_version": 1,
        "decision": (
            "minimum-cost-interventions-recover-cause-queries"
            if passed
            else "registered-estimation-or-design-check-failed"
        ),
        "passed": passed,
        "replicates": replicates,
        "seed": seed,
        "noise_standard_deviation": noise_standard_deviation,
        "cause_ids": list(CAUSES),
        "action_ids": list(ACTIONS),
        "action_costs": ACTION_COSTS,
        "selected_portfolio": portfolio.selected.to_record(),
        "held_interventions": list(held_actions),
        "metrics": metrics,
        "selected_90_coverage": coverage,
        "selected_per_cause_90_coverage": per_cause_coverage,
        "exact_recovery_error": exact_recovery_error,
        "declared_nuisance_material_identifiable": (
            confounded_estimate.query_identifiable
        ),
        "checks": checks,
        "certificate_id": cert.artifact_id,
        "portfolio_decision_id": portfolio.artifact_id,
        "claim_boundary": (
            "Controlled local-linear evidence for quantitative cause-query "
            "estimation and exact finite-roster intervention design. It does not "
            "establish a complete cause family, natural real-data attribution, "
            "unseen-object transfer, nonlinear physical validity, deployment "
            "safety, or state of the art."
        ),
    }
    result["result_id"] = _canonical_id(result)
    return result


def report(result: dict[str, Any]) -> str:
    lines = [
        "# Interventional cause estimation and design v1",
        "",
        f"**Decision:** `{result['decision']}`",
        "",
        "## Exact intervention design",
        "",
        f"- selected interventions: "
        f"`{', '.join(result['selected_portfolio']['intervention_ids'])}`;",
        f"- held intervention: `{', '.join(result['held_interventions'])}`;",
        f"- selected cost: `{result['selected_portfolio']['total_cost']:.3f}`;",
        f"- worst query noise gain: "
        f"`{result['selected_portfolio']['worst_query_noise_gain']:.6f}`.",
        "",
        "## Quantitative result",
        "",
        "| Method | Cause-query RMSE | Held-intervention RMSE |",
        "| --- | ---: | ---: |",
    ]
    names = {
        "source_action_minimum_norm": "Source action / minimum norm",
        "selected_intervention_portfolio": "Selected intervention portfolio",
        "all_interventions": "All interventions",
        "wrong_action_relation": "Wrong-action relation",
    }
    for key, label in names.items():
        row = result["metrics"][key]
        lines.append(
            f"| {label} | {row['cause_query_rmse']:.6f} | "
            f"{row['held_intervention_rmse']:.6f} |"
        )
    lines += [
        "",
        f"Selected nominal-90% cause-query coverage: "
        f"**{100 * result['selected_90_coverage']:.2f}%**.",
        "",
        "## Frozen checks",
        "",
    ]
    for name, passed in result["checks"].items():
        lines.append(f"- `{name}`: **{'pass' if passed else 'fail'}**")
    lines += [
        "",
        "## Claim boundary",
        "",
        result["claim_boundary"],
        "",
        f"Result ID: `{result['result_id']}`",
    ]
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replicates", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260902)
    parser.add_argument("--noise-standard-deviation", type=float, default=0.05)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = run(
        replicates=args.replicates,
        seed=args.seed,
        noise_standard_deviation=args.noise_standard_deviation,
    )
    args.output.mkdir(parents=True, exist_ok=False)
    (args.output / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    (args.output / "report.md").write_text(report(result), encoding="utf-8")
    print(
        json.dumps(
            {"decision": result["decision"], "result_id": result["result_id"]}
        )
    )
    return 0 if result["passed"] else 3


if __name__ == "__main__":
    raise SystemExit(main())
