"""Quantitative estimation and finite intervention design for twin-error causes.

The binary interventional certificate says whether a registered cause query is
identifiable after every competing cause and declared nuisance has been projected
out.  This module adds the corresponding Gauss--Markov query estimate, covariance,
finite-noise amplification, and an exact minimum-cost search over a finite
intervention roster.
"""

from __future__ import annotations

import itertools
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from numbers import Integral, Real
from typing import Any, Final, cast

import numpy as np

from bayesian_phystwin._canonical_contracts import (
    frozen_finite_json_mapping,
    immutable_array,
    literal_lower_hex,
    plain_json,
)
from bayesian_phystwin._portable_contracts import content_id
from bayesian_phystwin_experiments.interventional_cause_identifiability_v1 import (
    CauseResponseSignatureV1,
    InterventionalCauseIdentifiabilityCertificateV1,
)

INTERVENTIONAL_CAUSE_ESTIMATION_SCHEMA: Final = (
    "bayesian_phystwin.interventional_cause_estimation"
)
INTERVENTIONAL_CAUSE_ESTIMATION_VERSION: Final = 1
INTERVENTIONAL_CAUSE_ESTIMATION_SEMANTICS: Final = (
    "competitor-residualized-query-blue-and-exact-finite-design-v1"
)
INTERVENTIONAL_CAUSE_ESTIMATION_CLAIM_BOUNDARY: Final = (
    "A returned estimate is the minimum-covariance linear unbiased estimate of "
    "the registered cause query under the exact supplied whitened local model, "
    "finite cause family, declared nuisance design, intervention subset, and "
    "numerical tolerances. A selected portfolio is optimal only within the "
    "registered finite intervention roster and cost model. Neither result proves "
    "cause-family completeness, unique data-generating causation, correctness of "
    "the response signatures, unseen-object transfer, nonlinear validity, "
    "deployment safety, or state of the art."
)


def _digest(value: object, *, name: str) -> str:
    return cast(str, literal_lower_hex(value, name=name, lengths={64}))


def _matrix(value: object, *, name: str) -> np.ndarray:
    raw = np.asarray(value)
    if raw.dtype.kind not in "iuf":
        raise ValueError(f"{name} must contain real numeric values")
    result = np.ascontiguousarray(raw, dtype=np.float64)
    if result.ndim != 2 or not np.all(np.isfinite(result)):
        raise ValueError(f"{name} must be a finite matrix")
    return result


def _vector(value: object, *, name: str) -> np.ndarray:
    raw = np.asarray(value)
    if raw.dtype.kind not in "iuf":
        raise ValueError(f"{name} must contain real numeric values")
    result = np.ascontiguousarray(raw, dtype=np.float64)
    if result.ndim != 1 or result.size == 0 or not np.all(np.isfinite(result)):
        raise ValueError(f"{name} must be a nonempty finite vector")
    return result


def _finite_nonnegative(value: object, *, name: str) -> float:
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, Real):
        raise ValueError(f"{name} must be a finite nonnegative real number")
    result = float(value)
    if not np.isfinite(result) or result < 0.0:
        raise ValueError(f"{name} must be a finite nonnegative real number")
    return result


def _positive_integer(value: object, *, name: str) -> int:
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, Integral):
        raise ValueError(f"{name} must be a positive integer")
    result = int(value)
    if result <= 0:
        raise ValueError(f"{name} must be a positive integer")
    return result


def _immutable(value: object) -> np.ndarray:
    return cast(np.ndarray, immutable_array(value, dtype=np.float64))


def _svd(
    design: np.ndarray,
    certificate: InterventionalCauseIdentifiabilityCertificateV1,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, int]:
    left, singular, right_t = np.linalg.svd(design, full_matrices=True)
    scale = float(singular[0]) if singular.size else 0.0
    tolerance = max(
        float(certificate.absolute_rank_tolerance),
        float(certificate.relative_rank_tolerance) * scale,
    )
    rank = int(np.count_nonzero(singular > tolerance))
    return left, singular, right_t, rank


def _pseudoinverse(
    design: np.ndarray,
    certificate: InterventionalCauseIdentifiabilityCertificateV1,
) -> tuple[np.ndarray, np.ndarray, int]:
    left, singular, right_t, rank = _svd(design, certificate)
    if rank:
        inverse = (
            right_t[:rank].T
            @ np.diag(1.0 / singular[:rank])
            @ left[:, :rank].T
        )
    else:
        inverse = np.zeros((design.shape[1], design.shape[0]), dtype=np.float64)
    return inverse, singular, rank


def _projector(
    competing: np.ndarray,
    certificate: InterventionalCauseIdentifiabilityCertificateV1,
) -> np.ndarray:
    if competing.shape[1] == 0:
        return np.eye(competing.shape[0], dtype=np.float64)
    left, _, _, rank = _svd(competing, certificate)
    basis = left[:, :rank]
    return np.eye(competing.shape[0], dtype=np.float64) - basis @ basis.T


def _layout(
    certificate: InterventionalCauseIdentifiabilityCertificateV1,
) -> tuple[tuple[str, ...], dict[str, slice], int]:
    causes = tuple(certificate.cause_signatures)
    if len(causes) < 2:
        raise ValueError("at least two registered causes are required")
    cause_ids = tuple(cause.cause_id for cause in causes)
    if cause_ids != tuple(sorted(cause_ids)) or len(cause_ids) != len(set(cause_ids)):
        raise ValueError("cause roster must be sorted and unique")
    blocks = tuple(causes[0].intervention_blocks)
    intervention_ids = tuple(block.intervention_id for block in blocks)
    if not intervention_ids or intervention_ids != tuple(sorted(intervention_ids)):
        raise ValueError("intervention roster must be nonempty and sorted")
    if len(intervention_ids) != len(set(intervention_ids)):
        raise ValueError("intervention roster must be unique")
    dimensions = tuple(block.observation_dimension for block in blocks)
    for cause in causes[1:]:
        if cause.intervention_ids != intervention_ids:
            raise ValueError("all causes must share the intervention roster")
        if cause.observation_dimensions != dimensions:
            raise ValueError("all causes must share intervention row dimensions")
    slices: dict[str, slice] = {}
    start = 0
    for intervention_id, dimension in zip(intervention_ids, dimensions, strict=True):
        slices[intervention_id] = slice(start, start + dimension)
        start += dimension
    nuisance = _matrix(
        certificate.joint_whitened_nuisance_design,
        name="joint_whitened_nuisance_design",
    )
    if nuisance.shape[0] != start:
        raise ValueError("nuisance row count does not match the intervention roster")
    return intervention_ids, slices, start


def _selected_interventions(
    certificate: InterventionalCauseIdentifiabilityCertificateV1,
    intervention_ids: Sequence[str] | None,
) -> tuple[tuple[str, ...], np.ndarray]:
    roster, slices, row_count = _layout(certificate)
    selected = roster if intervention_ids is None else tuple(intervention_ids)
    if not selected or selected != tuple(sorted(selected)):
        raise ValueError("intervention_ids must be nonempty and sorted")
    if len(selected) != len(set(selected)):
        raise ValueError("intervention_ids must be unique")
    unknown = sorted(set(selected) - set(roster))
    if unknown:
        raise ValueError(f"unknown interventions: {unknown}")
    mask = np.zeros(row_count, dtype=bool)
    for intervention_id in selected:
        mask[slices[intervention_id]] = True
    return selected, mask


def _problem(
    certificate: InterventionalCauseIdentifiabilityCertificateV1,
    cause: CauseResponseSignatureV1,
    mask: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    physical = cause.stacked_response_signature[mask]
    nuisance = certificate.joint_whitened_nuisance_design[mask]
    competitors = [
        other.stacked_response_signature[mask]
        for other in certificate.cause_signatures
        if other.cause_id != cause.cause_id
    ]
    combined = np.hstack([nuisance, *competitors])
    projector = _projector(combined, certificate)
    query = _matrix(cause.cause_query_map, name="cause_query_map")
    return projector @ physical, projector, query


@dataclass(frozen=True, slots=True)
class CauseQueryEstimateV1:
    """One quantitative query estimate after projecting competing causes."""

    cause_id: str
    cause_query_id: str
    intervention_ids: tuple[str, ...]
    query_identifiable: bool
    identifiable_query_energy_fraction: float
    residualized_cause_rank: int
    cause_latent_dimension: int
    query_mean: np.ndarray
    query_covariance: np.ndarray
    query_noise_gain_spectral: float
    worst_case_query_error_bound: float
    profile_residual_norm: float
    unsupported_query_frobenius: float

    def to_record(self) -> dict[str, object]:
        return {
            "cause_id": self.cause_id,
            "cause_query_id": self.cause_query_id,
            "intervention_ids": list(self.intervention_ids),
            "query_identifiable": self.query_identifiable,
            "identifiable_query_energy_fraction": (
                self.identifiable_query_energy_fraction
            ),
            "residualized_cause_rank": self.residualized_cause_rank,
            "cause_latent_dimension": self.cause_latent_dimension,
            "query_mean": self.query_mean.tolist(),
            "query_covariance": self.query_covariance.tolist(),
            "query_noise_gain_spectral": self.query_noise_gain_spectral,
            "worst_case_query_error_bound": self.worst_case_query_error_bound,
            "profile_residual_norm": self.profile_residual_norm,
            "unsupported_query_frobenius": self.unsupported_query_frobenius,
        }


@dataclass(frozen=True, slots=True)
class InterventionalCauseEstimateV1:
    """Content-addressed estimates under one intervention subset."""

    certificate_id: str
    residual_id: str
    intervention_ids: tuple[str, ...]
    noise_variance: float
    noise_radius: float
    cause_estimates: tuple[CauseQueryEstimateV1, ...]
    metadata: Mapping[str, Any] = field(default_factory=dict)
    artifact_id: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "certificate_id",
            _digest(self.certificate_id, name="certificate_id"),
        )
        object.__setattr__(
            self,
            "residual_id",
            _digest(self.residual_id, name="residual_id"),
        )
        object.__setattr__(
            self,
            "metadata",
            frozen_finite_json_mapping(self.metadata, name="cause estimate metadata"),
        )
        expected = cast(str, content_id(self.descriptor()))
        if self.artifact_id is not None and _digest(
            self.artifact_id, name="artifact_id"
        ) != expected:
            raise ValueError("estimate artifact_id does not match content")
        object.__setattr__(self, "artifact_id", expected)

    @property
    def all_queries_identifiable(self) -> bool:
        return all(item.query_identifiable for item in self.cause_estimates)

    def result_for(self, cause_id: str) -> CauseQueryEstimateV1:
        matches = [item for item in self.cause_estimates if item.cause_id == cause_id]
        if len(matches) != 1:
            raise KeyError(cause_id)
        return matches[0]

    def descriptor(self) -> dict[str, object]:
        return {
            "schema": INTERVENTIONAL_CAUSE_ESTIMATION_SCHEMA,
            "schema_version": INTERVENTIONAL_CAUSE_ESTIMATION_VERSION,
            "artifact_kind": "InterventionalCauseEstimateV1",
            "semantics": INTERVENTIONAL_CAUSE_ESTIMATION_SEMANTICS,
            "certificate_id": self.certificate_id,
            "residual_id": self.residual_id,
            "intervention_ids": list(self.intervention_ids),
            "noise_variance": self.noise_variance,
            "noise_radius": self.noise_radius,
            "cause_estimates": [item.to_record() for item in self.cause_estimates],
            "metadata": plain_json(self.metadata),
            "claim_boundary": INTERVENTIONAL_CAUSE_ESTIMATION_CLAIM_BOUNDARY,
        }

    def to_record(self) -> dict[str, object]:
        return {**self.descriptor(), "artifact_id": self.artifact_id}


@dataclass(frozen=True, slots=True)
class InterventionPortfolioCandidateV1:
    intervention_ids: tuple[str, ...]
    total_cost: float
    all_required_queries_identifiable: bool
    worst_query_noise_gain: float
    minimum_residualized_singular_value: float
    per_cause_query_noise_gain: tuple[tuple[str, float], ...]

    def to_record(self) -> dict[str, object]:
        return {
            "intervention_ids": list(self.intervention_ids),
            "total_cost": self.total_cost,
            "all_required_queries_identifiable": (
                self.all_required_queries_identifiable
            ),
            "worst_query_noise_gain": self.worst_query_noise_gain,
            "minimum_residualized_singular_value": (
                self.minimum_residualized_singular_value
            ),
            "per_cause_query_noise_gain": [
                [cause_id, gain] for cause_id, gain in self.per_cause_query_noise_gain
            ],
        }


@dataclass(frozen=True, slots=True)
class InterventionPortfolioDecisionV1:
    certificate_id: str
    required_cause_ids: tuple[str, ...]
    mandatory_intervention_ids: tuple[str, ...]
    maximum_total_cost: float
    maximum_query_noise_gain: float
    selected: InterventionPortfolioCandidateV1 | None
    feasible_candidates: tuple[InterventionPortfolioCandidateV1, ...]
    evaluated_candidate_count: int
    metadata: Mapping[str, Any] = field(default_factory=dict)
    artifact_id: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "certificate_id",
            _digest(self.certificate_id, name="certificate_id"),
        )
        object.__setattr__(
            self,
            "metadata",
            frozen_finite_json_mapping(self.metadata, name="portfolio metadata"),
        )
        expected = cast(str, content_id(self.descriptor()))
        if self.artifact_id is not None and _digest(
            self.artifact_id, name="artifact_id"
        ) != expected:
            raise ValueError("portfolio artifact_id does not match content")
        object.__setattr__(self, "artifact_id", expected)

    @property
    def feasible(self) -> bool:
        return self.selected is not None

    def descriptor(self) -> dict[str, object]:
        return {
            "schema": INTERVENTIONAL_CAUSE_ESTIMATION_SCHEMA,
            "schema_version": INTERVENTIONAL_CAUSE_ESTIMATION_VERSION,
            "artifact_kind": "InterventionPortfolioDecisionV1",
            "semantics": INTERVENTIONAL_CAUSE_ESTIMATION_SEMANTICS,
            "certificate_id": self.certificate_id,
            "required_cause_ids": list(self.required_cause_ids),
            "mandatory_intervention_ids": list(self.mandatory_intervention_ids),
            "maximum_total_cost": self.maximum_total_cost,
            "maximum_query_noise_gain": self.maximum_query_noise_gain,
            "selected": self.selected.to_record() if self.selected else None,
            "feasible_candidates": [
                item.to_record() for item in self.feasible_candidates
            ],
            "evaluated_candidate_count": self.evaluated_candidate_count,
            "metadata": plain_json(self.metadata),
            "claim_boundary": INTERVENTIONAL_CAUSE_ESTIMATION_CLAIM_BOUNDARY,
        }

    def to_record(self) -> dict[str, object]:
        return {**self.descriptor(), "artifact_id": self.artifact_id}


def estimate_interventional_causes(
    certificate: InterventionalCauseIdentifiabilityCertificateV1,
    whitened_residual: object,
    *,
    intervention_ids: Sequence[str] | None = None,
    noise_variance: float = 1.0,
    noise_radius: float = 0.0,
    metadata: Mapping[str, Any] | None = None,
) -> InterventionalCauseEstimateV1:
    """Estimate every registered cause query under a frozen intervention subset."""

    certificate_id = _digest(certificate.artifact_id, name="certificate artifact_id")
    selected, mask = _selected_interventions(certificate, intervention_ids)
    _, _, row_count = _layout(certificate)
    residual = _vector(whitened_residual, name="whitened_residual")
    if residual.size != row_count:
        raise ValueError("whitened_residual length does not match stacked signatures")
    variance = _finite_nonnegative(noise_variance, name="noise_variance")
    if variance <= 0.0:
        raise ValueError("noise_variance must be positive")
    radius = _finite_nonnegative(noise_radius, name="noise_radius")
    selected_residual = residual[mask]
    estimates: list[CauseQueryEstimateV1] = []
    for cause in certificate.cause_signatures:
        residualized, projector, query = _problem(certificate, cause, mask)
        inverse, _, rank = _pseudoinverse(residualized, certificate)
        supported = query @ inverse @ residualized
        unsupported = query - supported
        query_norm = float(np.linalg.norm(query, ord="fro"))
        unsupported_norm = float(np.linalg.norm(unsupported, ord="fro"))
        threshold = float(certificate.absolute_rank_tolerance) + float(
            certificate.identifiability_tolerance
        ) * query_norm
        identifiable = bool(query_norm == 0.0 or unsupported_norm <= threshold)
        energy = (
            1.0
            if query_norm == 0.0
            else float(
                np.clip(1.0 - unsupported_norm**2 / query_norm**2, 0.0, 1.0)
            )
        )
        factor = supported @ inverse @ projector
        mean = factor @ selected_residual
        covariance = variance * factor @ factor.T
        covariance = 0.5 * (covariance + covariance.T)
        singular = np.linalg.svd(factor, compute_uv=False)
        gain = float(singular[0]) if singular.size else 0.0
        fitted = residualized @ inverse @ (projector @ selected_residual)
        profile = float(np.linalg.norm(projector @ selected_residual - fitted))
        estimates.append(
            CauseQueryEstimateV1(
                cause_id=cause.cause_id,
                cause_query_id=cause.cause_query_id,
                intervention_ids=selected,
                query_identifiable=identifiable,
                identifiable_query_energy_fraction=energy,
                residualized_cause_rank=rank,
                cause_latent_dimension=cause.latent_dimension,
                query_mean=_immutable(mean),
                query_covariance=_immutable(covariance),
                query_noise_gain_spectral=gain,
                worst_case_query_error_bound=radius * gain,
                profile_residual_norm=profile,
                unsupported_query_frobenius=unsupported_norm,
            )
        )
    residual_id = cast(
        str,
        content_id(
            {
                "kind": "whitened-interventional-residual-v1",
                "certificate_id": certificate_id,
                "values": residual.tolist(),
            }
        ),
    )
    return InterventionalCauseEstimateV1(
        certificate_id=certificate_id,
        residual_id=residual_id,
        intervention_ids=selected,
        noise_variance=variance,
        noise_radius=radius,
        cause_estimates=tuple(estimates),
        metadata={} if metadata is None else metadata,
    )


def _portfolio_candidate(
    certificate: InterventionalCauseIdentifiabilityCertificateV1,
    intervention_ids: tuple[str, ...],
    costs: Mapping[str, float],
    required_causes: tuple[str, ...],
) -> InterventionPortfolioCandidateV1:
    _, mask = _selected_interventions(certificate, intervention_ids)
    gains: list[tuple[str, float]] = []
    minimum_singular = 1e300
    all_identifiable = True
    for cause in certificate.cause_signatures:
        if cause.cause_id not in required_causes:
            continue
        residualized, projector, query = _problem(certificate, cause, mask)
        inverse, singular, rank = _pseudoinverse(residualized, certificate)
        if rank:
            minimum_singular = min(minimum_singular, float(singular[rank - 1]))
        else:
            minimum_singular = 0.0
        unsupported = query - query @ inverse @ residualized
        query_norm = float(np.linalg.norm(query, ord="fro"))
        threshold = float(certificate.absolute_rank_tolerance) + float(
            certificate.identifiability_tolerance
        ) * query_norm
        identifiable = bool(
            query_norm == 0.0 or float(np.linalg.norm(unsupported)) <= threshold
        )
        all_identifiable = all_identifiable and identifiable
        if identifiable:
            factor = query @ inverse @ projector
            values = np.linalg.svd(factor, compute_uv=False)
            gain = float(values[0]) if values.size else 0.0
        else:
            gain = 1e300
        gains.append((cause.cause_id, gain))
    if not gains:
        raise ValueError("required cause roster is empty")
    return InterventionPortfolioCandidateV1(
        intervention_ids=intervention_ids,
        total_cost=float(sum(costs[item] for item in intervention_ids)),
        all_required_queries_identifiable=all_identifiable,
        worst_query_noise_gain=max(gain for _, gain in gains),
        minimum_residualized_singular_value=(
            0.0 if minimum_singular == 1e300 else minimum_singular
        ),
        per_cause_query_noise_gain=tuple(gains),
    )


def select_intervention_portfolio(
    certificate: InterventionalCauseIdentifiabilityCertificateV1,
    intervention_costs: Mapping[str, object],
    *,
    required_cause_ids: Sequence[str] | None = None,
    mandatory_intervention_ids: Sequence[str] = (),
    maximum_total_cost: float = 1e300,
    maximum_query_noise_gain: float = 1e300,
    maximum_exact_interventions: int = 15,
    metadata: Mapping[str, Any] | None = None,
) -> InterventionPortfolioDecisionV1:
    """Return the exact minimum-cost stable portfolio from a finite roster."""

    certificate_id = _digest(certificate.artifact_id, name="certificate artifact_id")
    roster, _, _ = _layout(certificate)
    exact_limit = _positive_integer(
        maximum_exact_interventions,
        name="maximum_exact_interventions",
    )
    if len(roster) > exact_limit:
        raise ValueError("intervention roster exceeds exact-search limit")
    if set(intervention_costs) != set(roster):
        raise ValueError("intervention_costs must cover the exact intervention roster")
    costs = {
        item: _finite_nonnegative(intervention_costs[item], name=f"cost for {item}")
        for item in roster
    }
    cause_ids = tuple(cause.cause_id for cause in certificate.cause_signatures)
    required = cause_ids if required_cause_ids is None else tuple(required_cause_ids)
    if not required or required != tuple(sorted(required)):
        raise ValueError("required_cause_ids must be nonempty and sorted")
    if len(required) != len(set(required)) or not set(required) <= set(cause_ids):
        raise ValueError("required_cause_ids must be unique registered causes")
    mandatory = tuple(mandatory_intervention_ids)
    if mandatory != tuple(sorted(mandatory)) or len(mandatory) != len(set(mandatory)):
        raise ValueError("mandatory_intervention_ids must be sorted and unique")
    if not set(mandatory) <= set(roster):
        raise ValueError("mandatory_intervention_ids contains an unknown intervention")
    max_cost = _finite_nonnegative(maximum_total_cost, name="maximum_total_cost")
    max_gain = _finite_nonnegative(
        maximum_query_noise_gain,
        name="maximum_query_noise_gain",
    )
    if max_gain <= 0.0:
        raise ValueError("maximum_query_noise_gain must be positive")

    feasible: list[InterventionPortfolioCandidateV1] = []
    evaluated = 0
    optional = tuple(item for item in roster if item not in mandatory)
    for count in range(len(optional) + 1):
        for extra in itertools.combinations(optional, count):
            selected = tuple(sorted((*mandatory, *extra)))
            if not selected:
                continue
            evaluated += 1
            candidate = _portfolio_candidate(
                certificate,
                selected,
                costs,
                required,
            )
            if (
                candidate.all_required_queries_identifiable
                and candidate.total_cost <= max_cost
                and candidate.worst_query_noise_gain <= max_gain
            ):
                feasible.append(candidate)
    ordered = tuple(
        sorted(
            feasible,
            key=lambda item: (
                item.total_cost,
                item.worst_query_noise_gain,
                len(item.intervention_ids),
                item.intervention_ids,
            ),
        )
    )
    return InterventionPortfolioDecisionV1(
        certificate_id=certificate_id,
        required_cause_ids=required,
        mandatory_intervention_ids=mandatory,
        maximum_total_cost=max_cost,
        maximum_query_noise_gain=max_gain,
        selected=ordered[0] if ordered else None,
        feasible_candidates=ordered,
        evaluated_candidate_count=evaluated,
        metadata={} if metadata is None else metadata,
    )
