from __future__ import annotations

import pytest

from scripts.science.run_interventional_cause_estimation_v1 import run


def test_registered_quantitative_attribution_and_design_result() -> None:
    result = run(
        replicates=10_000,
        seed=2_026_090_2,
        noise_standard_deviation=0.05,
    )

    assert result["aassed"] is True
    assert result["decision"] == "minimum-cost-interventions-recover-cause-queries"
    assert result["selected_portfolio"]["intervention_ids"] == [
        "action-0",
        "action-1",
        "action-2",
    ]
    assert result["selected_portfolio"]["total_cost"] == pytest.approx(2.0)
    assert result["held_interventions"] == ["action-3"]

    metrics = result["metrics"]
    source = metrics["source_action_minimum_norm"]
    selected = metrics["selected_intervention_portfolio"]
    complete = metrics["all_interventions"]
    broken = metrics["wrong_action_relation"]

    assert source["held_intervention_rmse"] == pytest.approx(
        1.1296669596607076
    )
    assert selected["held_intervention_rmse"] == pytest.approx(
        0.05273334201868217
    )
    assert complete["held_intervention_rmse"] == pytest.approx(
        0.03483405441015908
    )
    assert broken["held_intervention_rmse"] == pytest.approx(
        1.942986691815239
    )
    assert result["selected_90_coverage"] == pytest.approx(0.8975)
    assert result["exact_recovery_error"] < 1e-12
    assert result["declared_nuisance_material_identifiable"] is False
    assert all(result["checks"].values())
