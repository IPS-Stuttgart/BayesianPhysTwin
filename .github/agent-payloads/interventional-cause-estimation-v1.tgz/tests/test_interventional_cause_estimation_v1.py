from __future__ import annotations

import numpy as np
import pytest

from bayesian_phystwin_experiments.interventional_cause_estimation_v1 import (
    estimate_interventional_causes,
    select_intervention_portfolio,
)
from bayesian_phystwin_experiments.interventional_cause_identifiability_v1 import (
    CauseResponseSignatureV1,
    InterventionalCauseIdentifiabilityCertificateV1,
    InterventionResponseBlockV1,
)

SHA = "a" * 64
ACTIONS = ("action-0", "action-1", "action-2", "action-3")


def columns() -> dict[str, np.ndarray]:
    return {
        "observation_bias": np.asarray([[1.0, 0.0, 0.0]] * 4),
        "physical_parameter": np.asarray(
            [
                [1.0, 0.0, 0.0],
                [0.0, 1.0, 0.2],
                [0.2, 0.3, 1.0],
                [0.5, 1.0, -0.3],
            ]
        ),
        "physical_state": np.asarray(
            [
                [1.0, 0.0, 0.0],
                [1.0, 0.5, 0.0],
                [1.0, -0.5, 0.5],
                [1.0, 0.2, -0.6],
            ]
        ),
        "realized_intervention": np.asarray(
            [
                [1.0, 0.0, 0.0],
                [0.5, -0.5, 1.0],
                [-0.5, 1.0, 0.1],
                [1.0, -1.0, 0.5],
            ]
        ),
        "source_local_discrepancy": np.asarray(
            [
                [1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
            ]
        ),
    }


def _cause(cause_id: str, values: np.ndarray) -> CauseResponseSignatureV1:
    return CauseResponseSignatureV1(
        cause_id=cause_id,
        latent_coordinates_id=SHA,
        cause_query_id=SHA,
        intervention_blocks=tuple(
            InterventionResponseBlockV1(
                intervention_id=action,
                response_signature_id=SHA,
                whitened_response_signature=values[index, :, None],
            )
            for index, action in enumerate(ACTIONS)
        ),
        cause_query_map=np.eye(1),
    )


def certificate(
    nuisance: np.ndarray | None = None,
) -> InterventionalCauseIdentifiabilityCertificateV1:
    values = columns()
    if nuisance is None:
        nuisance = np.empty((12, 0), dtype=np.float64)
    return InterventionalCauseIdentifiabilityCertificateV1(
        observation_whitening_id=SHA,
        declared_nuisance_id=SHA,
        cause_family_id=SHA,
        cause_signatures=tuple(
            _cause(cause_id, values[cause_id]) for cause_id in sorted(values)
        ),
        joint_whitened_nuisance_design=nuisance,
    )


def residual(amplitudes: dict[str, float]) -> np.ndarray:
    return sum(
        amplitude * columns()[cause].reshape(-1)
        for cause, amplitude in amplitudes.items()
    )


def test_all_interventions_recover_simultaneous_cause_queries() -> None:
    truth = {
        "observation_bias": 0.3,
        "physical_parameter": -0.7,
        "physical_state": 0.4,
        "realized_intervention": 1.1,
        "source_local_discrepancy": -0.2,
    }
    result = estimate_interventional_causes(
        certificate(),
        residual(truth),
        noise_variance=0.04,
        noise_radius=0.5,
    )

    assert result.all_queries_identifiable
    for cause_id, expected in truth.items():
        estimate = result.result_for(cause_id)
        assert estimate.query_identifiable
        assert estimate.query_mean == pytest.approx([expected], abs=1e-10)
        assert estimate.query_covariance.shape == (1, 1)
        assert estimate.query_covariance[0, 0] > 0.0
        assert estimate.worst_case_query_error_bound >= 0.0
        assert not estimate.query_mean.flags.writeable
        assert not estimate.query_covariance.flags.writeable


def test_source_action_is_explicitly_unresolved() -> None:
    result = estimate_interventional_causes(
        certificate(),
        residual({"physical_parameter": 1.0}),
        intervention_ids=("action-0",),
    )

    assert not result.all_queries_identifiable
    assert all(not item.query_identifiable for item in result.cause_estimates)
    assert all(
        item.identifiable_query_energy_fraction == pytest.approx(0.0)
        for item in result.cause_estimates
    )


def test_exact_portfolio_search_selects_lowest_cost_stable_design() -> None:
    decision = select_intervention_portfolio(
        certificate(),
        {
            "action-0": 0.0,
            "action-1": 1.0,
            "action-2": 1.0,
            "action-3": 3.0,
        },
        mandatory_intervention_ids=("action-0",),
        maximum_query_noise_gain=20.0,
    )

    assert decision.feasible
    assert decision.selected is not None
    assert decision.selected.intervention_ids == (
        "action-0",
        "action-1",
        "action-2",
    )
    assert decision.selected.total_cost == pytest.approx(2.0)
    assert decision.selected.total_cost == min(
        item.total_cost for item in decision.feasible_candidates
    )
    assert decision.selected.worst_query_noise_gain <= 20.0


def test_noise_gain_limit_can_force_infeasibility() -> None:
    decision = select_intervention_portfolio(
        certificate(),
        {action: 1.0 for action in ACTIONS},
        maximum_query_noise_gain=1e-6,
    )
    assert not decision.feasible
    assert decision.selected is None


def test_declared_nuisance_can_destroy_material_attribution() -> None:
    material = columns()["physical_parameter"].reshape(-1, 1)
    result = estimate_interventional_causes(
        certificate(material),
        residual({"physical_parameter": 1.0}),
    )
    estimate = result.result_for("physical_parameter")
    assert not estimate.query_identifiable
    assert estimate.residualized_cause_rank == 0


def test_invalid_residual_and_cost_rosters_fail_closed() -> None:
    cert = certificate()
    with pytest.raises(ValueError, match="length"):
        estimate_interventional_causes(cert, np.zeros(3))
    with pytest.raises(ValueError, match="exact intervention roster"):
        select_intervention_portfolio(cert, {"action-0": 1.0})
