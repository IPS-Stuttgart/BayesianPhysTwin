#!/usr/bin/env python3
"""Held-out-query test of Bayesian joint-belief value on Deform360.

The experiment reuses the exact frozen v3 point predictor and the exact
parent-bound 92-object Deform360 carriers.  Predictive means are identical in
all arms.  The primary shared-calibration regime also keeps coordinate
marginals and the source-derived scalar calibration identical, changing only
cross-coordinate dependence.  A second regime independently calibrates every
arm on one deterministic half of a 64-query DCT bank and evaluates the other
half.  A source-only width-matched diagonal control and a low-rank component
ablation test whether any advantage is explained only by interval width or
retained marginal variance.

The target episodes were opened by predecessor studies.  This script therefore
produces retrospective mechanism evidence, not a fresh confirmation.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import math
import os
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from statistics import NormalDist
from typing import Any, Mapping, Sequence

import numpy as np

SCHEMA = "bayesian-phystwin/deform360-heldout-query-value-result-v7"
PROTOCOL_SCHEMA = "bayesian-phystwin/deform360-heldout-query-value-protocol-v7"
SHARED_ARMS = (
    "full_low_rank",
    "diagonal_marginal_matched",
    "scrambled_marginal_matched",
)
BASE_CALIBRATED_ARMS = SHARED_ARMS + ("local_diagonal_only",)
CALIBRATED_ARMS = BASE_CALIBRATED_ARMS + ("diagonal_width_matched",)
REGIMES = {
    "shared_calibration": SHARED_ARMS,
    "arm_calibrated": CALIBRATED_ARMS,
}
METRICS = (
    "target_query_nanees",
    "target_90_coverage",
    "mean_90_interval_width",
    "query_nll",
    "event_brier",
    "event_log_loss",
    "decision_loss",
    "decision_regret",
    "acceptance_fraction",
    "harmful_accept_fraction_all",
    "harmful_accept_rate_given_accept",
)
COMPARISON_METRICS = (
    "decision_loss",
    "event_brier",
    "query_nll",
    "event_log_loss",
)
FIELD_ROWS = 6
FIELD_COLUMNS = 16
FIELD_DIMENSION_PER_SENSOR = FIELD_ROWS * FIELD_COLUMNS
_EPS = 1e-12
_NORMAL = NormalDist()


@dataclass(frozen=True)
class Query:
    name: str
    sensor_mode: int
    row_mode: int
    column_mode: int
    event: str
    weight: np.ndarray


def load_module(path: Path, name: str) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import module: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def canonical_digest(value: Any) -> str:
    payload = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def array_digest(value: np.ndarray) -> str:
    array = np.ascontiguousarray(value)
    digest = hashlib.sha256()
    digest.update(array.dtype.str.encode("ascii"))
    digest.update(b"\0")
    digest.update(json.dumps(list(array.shape), separators=(",", ":")).encode("ascii"))
    digest.update(b"\0")
    digest.update(array.tobytes(order="C"))
    return digest.hexdigest()


def git_output(root: Path, *arguments: str) -> str:
    return subprocess.check_output(
        ["git", "-C", str(root), *arguments],
        text=True,
    ).strip()


def require_mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{name} must be a mapping")
    return value


def validate_protocol(
    protocol: Mapping[str, Any],
    *,
    data_root: Path,
    recovery_root: Path,
    original_v6_root: Path,
    parent_control_root: Path,
    frozen_root: Path,
) -> None:
    if protocol.get("schema") != PROTOCOL_SCHEMA:
        raise ValueError("unexpected v7 protocol schema")
    if protocol.get("schema_version") != 7:
        raise ValueError("unexpected v7 protocol version")
    if protocol.get("status") != "frozen-before-v7-target-reexecution":
        raise ValueError("v7 protocol is not frozen")
    if Path(str(protocol.get("dataset_root"))) != data_root:
        raise ValueError("dataset root changed")

    lineage = require_mapping(protocol.get("lineage"), "lineage")
    revision_roots = (
        (recovery_root, "bound_carrier_recovery_revision"),
        (original_v6_root, "original_v6_revision"),
        (parent_control_root, "parent_confirmation_control_revision"),
        (frozen_root, "frozen_point_revision"),
    )
    for root, key in revision_roots:
        if git_output(root, "rev-parse", "HEAD") != lineage.get(key):
            raise ValueError(f"lineage revision changed: {key}")
    original_runner = original_v6_root / str(lineage["original_v6_runner_path"])
    if sha256_file(original_runner) != lineage.get("original_v6_runner_sha256"):
        raise ValueError("original v6 runner bytes changed")

    transfer = require_mapping(protocol.get("query_transfer"), "query_transfer")
    expected_transfer = {
        "generator": "tensor_product_dct_low_frequency_v1",
        "field_rows": FIELD_ROWS,
        "field_columns": FIELD_COLUMNS,
        "query_count": 64,
        "calibration_query_count": 32,
        "evaluation_query_count": 32,
        "mode_order": (
            "ascending total frequency, then sensor mode, row mode, column mode"
        ),
        "weight_normalization": "unit_l1",
        "constant_mode_event": "upper",
        "nonconstant_mode_event": "absolute",
        "split_method": "sha256(seed, query name), ascending digest",
        "split_seed": 260903,
        "target_queries_used_for_uncertainty_calibration": False,
        "source_truth_may_set_each_event_threshold": True,
    }
    for key, expected in expected_transfer.items():
        if transfer.get(key) != expected:
            raise ValueError(f"query-transfer contract changed: {key}")

    covariance = require_mapping(protocol.get("covariance_arms"), "covariance_arms")
    if tuple(covariance.get("shared_calibration", ())) != SHARED_ARMS:
        raise ValueError("shared-calibration arm roster changed")
    if tuple(covariance.get("arm_calibrated", ())) != CALIBRATED_ARMS:
        raise ValueError("arm-calibrated roster changed")

    calibration = require_mapping(protocol.get("calibration"), "calibration")
    if calibration.get("source_error_centering") != (
        "subtract the pooled source residual mean coordinate-wise"
    ):
        raise ValueError("source-error centering changed")
    if calibration.get("global_variance_scale") != (
        "mean squared standardized source error pooled across calibration queries and source windows"
    ):
        raise ValueError("global variance-scale rule changed")
    if float(calibration.get("coverage_probability", math.nan)) != 0.9:
        raise ValueError("coverage probability changed")
    if calibration.get("shared_regime_reference_arm") != "full_low_rank":
        raise ValueError("shared calibration reference changed")
    if calibration.get("shared_regime_reuses_scale_and_radius_for_controls") is not True:
        raise ValueError("shared calibration must be reused unchanged")
    if (
        calibration.get("arm_calibrated_regime_fits_each_non_width_arm_independently")
        is not True
    ):
        raise ValueError("independent source calibration must be enabled")
    if calibration.get("width_matching_uses_target_outcomes") is not False:
        raise ValueError("width matching may not use target outcomes")
    minimum_scale = float(calibration.get("minimum_variance_scale", math.nan))
    if not math.isfinite(minimum_scale) or minimum_scale <= 0.0:
        raise ValueError("minimum variance scale is invalid")

    evaluation = require_mapping(protocol.get("evaluation"), "evaluation")
    if int(evaluation.get("object_count", -1)) != 92:
        raise ValueError("object count changed")
    if float(evaluation.get("event_threshold_quantile", math.nan)) != 0.9:
        raise ValueError("event threshold quantile changed")
    fallback = float(evaluation.get("fallback_cost", math.nan))
    if not 0.0 < fallback < 1.0:
        raise ValueError("fallback cost must be in (0,1)")
    if int(evaluation.get("bootstrap_repetitions", 0)) != 10000:
        raise ValueError("bootstrap repetitions changed")
    if tuple(evaluation.get("reported_metrics", ())) != METRICS:
        raise ValueError("reported metric roster changed")

    boundary = require_mapping(protocol.get("information_boundary"), "information_boundary")
    required_true = (
        "retrospective_target_reuse",
        "exact_parent_bound_numeric_carriers_required",
    )
    required_false = (
        "live_unbound_numeric_payloads_may_open",
        "point_predictor_may_change",
        "target_outcomes_may_tune_queries",
        "target_outcomes_may_tune_query_split",
        "target_outcomes_may_tune_calibration",
        "target_outcomes_may_select_covariance_arm",
        "camera_pixels_may_open",
        "geometry_or_point_cloud_may_open",
        "new_measurements_collected",
    )
    for key in required_true:
        if boundary.get(key) is not True:
            raise ValueError(f"required information boundary disabled: {key}")
    for key in required_false:
        if boundary.get(key) is not False:
            raise ValueError(f"forbidden information flow enabled: {key}")
    for key in (
        "paper_claim_authorized",
        "fresh_confirmation_authorized",
        "deployment_claim_authorized",
    ):
        if protocol.get(key) is not False:
            raise ValueError(f"protocol self-authorizes forbidden claim: {key}")


def dct_mode(length: int, index: int) -> np.ndarray:
    if length < 1 or not 0 <= index < length:
        raise ValueError("invalid DCT mode")
    coordinates = np.arange(length, dtype=np.float64) + 0.5
    return np.cos(math.pi * index * coordinates / length)


def build_query_bank(dimension: int, query_count: int) -> dict[str, Query]:
    if dimension % FIELD_DIMENSION_PER_SENSOR:
        raise ValueError("field dimension is not a whole number of tactile grids")
    sensor_count = dimension // FIELD_DIMENSION_PER_SENSOR
    if sensor_count < 2:
        raise ValueError("at least two tactile sensors are required")
    modes = [
        (sensor + row + column, sensor, row, column)
        for sensor in range(sensor_count)
        for row in range(FIELD_ROWS)
        for column in range(FIELD_COLUMNS)
    ]
    modes.sort()
    if query_count < 2 or query_count > len(modes):
        raise ValueError("query count is invalid for the field dimension")

    bank: dict[str, Query] = {}
    for _, sensor, row, column in modes[:query_count]:
        sensor_values = dct_mode(sensor_count, sensor)
        row_values = dct_mode(FIELD_ROWS, row)
        column_values = dct_mode(FIELD_COLUMNS, column)
        weight = (
            sensor_values[:, None, None]
            * row_values[None, :, None]
            * column_values[None, None, :]
        ).reshape(-1)
        normalizer = float(np.sum(np.abs(weight)))
        if normalizer <= 0.0 or not math.isfinite(normalizer):
            raise RuntimeError("query normalization failed")
        weight = np.asarray(weight / normalizer, dtype=np.float64)
        name = f"dct_s{sensor:02d}_y{row:02d}_x{column:02d}"
        event = "upper" if sensor == row == column == 0 else "absolute"
        bank[name] = Query(name, sensor, row, column, event, weight)

    if len(bank) != query_count:
        raise RuntimeError("query bank contains duplicate names")
    for query in bank.values():
        if query.weight.shape != (dimension,):
            raise RuntimeError("query weight shape changed")
        if not np.all(np.isfinite(query.weight)):
            raise RuntimeError("query weight contains nonfinite values")
        if not math.isclose(
            float(np.sum(np.abs(query.weight))),
            1.0,
            rel_tol=0.0,
            abs_tol=1e-12,
        ):
            raise RuntimeError("query weight is not unit-L1 normalized")
    return bank


def split_query_names(
    bank: Mapping[str, Query],
    calibration_count: int,
    seed: int,
) -> tuple[list[str], list[str]]:
    if not 0 < calibration_count < len(bank):
        raise ValueError("query split size is invalid")
    scored = sorted(
        (
            hashlib.sha256(f"{seed}\0{name}".encode("utf-8")).digest(),
            name,
        )
        for name in bank
    )
    calibration = [name for _, name in scored[:calibration_count]]
    evaluation = [name for _, name in scored[calibration_count:]]
    if set(calibration) & set(evaluation):
        raise RuntimeError("query split overlaps")
    if set(calibration) | set(evaluation) != set(bank):
        raise RuntimeError("query split is incomplete")
    return calibration, evaluation


def marginal_variance(model: Any) -> np.ndarray:
    factor = np.asarray(model.factor, dtype=np.float64)
    return float(model.multiplier) * (
        np.asarray(model.diagonal, dtype=np.float64) + np.sum(factor * factor, axis=1)
    )


def query_variance(model: Any, weight: np.ndarray) -> float:
    diagonal = float(model.multiplier) * np.asarray(model.diagonal, dtype=np.float64)
    factor = math.sqrt(float(model.multiplier)) * np.asarray(
        model.factor, dtype=np.float64
    )
    value = float(np.sum(weight * weight * diagonal))
    if factor.shape[1]:
        projected = weight @ factor
        value += float(projected @ projected)
    return max(value, _EPS)


def scrambled_factor(factor: np.ndarray, *, seed: int) -> np.ndarray:
    source = np.asarray(factor, dtype=np.float64)
    if source.ndim != 2:
        raise ValueError("factor must be a matrix")
    result = np.zeros_like(source)
    if source.shape[1] == 0:
        return result
    norms = np.linalg.norm(source, axis=1)
    indices = np.flatnonzero(norms > _EPS)
    if len(indices) == 0:
        return result
    directions = source[indices] / norms[indices, None]
    rng = np.random.default_rng(seed)
    permutation = rng.permutation(len(indices))
    if len(indices) > 1 and np.array_equal(permutation, np.arange(len(indices))):
        permutation = np.roll(permutation, 1)
    signs = rng.choice(np.asarray([-1.0, 1.0]), size=len(indices))
    result[indices] = norms[indices, None] * directions[permutation] * signs[:, None]
    return result


def build_covariance_models(base: Any, covariance: Any, *, seed: int) -> dict[str, Any]:
    factor = np.asarray(covariance.factor, dtype=np.float64)
    diagonal = np.asarray(covariance.diagonal, dtype=np.float64)
    total = diagonal + np.sum(factor * factor, axis=1)
    empty = np.empty((len(total), 0), dtype=np.float64)
    scrambled = scrambled_factor(factor, seed=seed)

    def make(diagonal_value: np.ndarray, factor_value: np.ndarray) -> Any:
        return base.CovarianceModel(
            np.asarray(covariance.mean_error, dtype=np.float64).copy(),
            np.asarray(diagonal_value, dtype=np.float64).copy(),
            np.asarray(factor_value, dtype=np.float64).copy(),
            float(covariance.multiplier),
            float(covariance.marginal_z),
            float(covariance.source_marginal_coverage),
            float(covariance.source_joint_nanees),
        )

    result = {
        "full_low_rank": covariance,
        "diagonal_marginal_matched": make(total, empty),
        "scrambled_marginal_matched": make(diagonal, scrambled),
        "local_diagonal_only": make(diagonal, empty),
    }
    reference = marginal_variance(covariance)
    for name in SHARED_ARMS:
        if not np.allclose(
            marginal_variance(result[name]),
            reference,
            rtol=1e-12,
            atol=1e-12,
        ):
            raise RuntimeError(f"raw coordinate marginals changed for {name}")
    return result


def calibration_record(
    source_errors: np.ndarray,
    bank: Mapping[str, Query],
    query_names: Sequence[str],
    model: Any,
    *,
    scale: float,
    radius_multiplier: float,
) -> dict[str, float]:
    standardized: list[np.ndarray] = []
    widths: list[float] = []
    for name in query_names:
        query = bank[name]
        variance = scale * query_variance(model, query.weight)
        error = source_errors @ query.weight
        standardized.append(np.abs(error) / math.sqrt(max(variance, _EPS)))
        widths.append(2.0 * radius_multiplier * math.sqrt(max(variance, _EPS)))
    pooled = np.concatenate(standardized)
    return {
        "variance_scale": float(scale),
        "radius_multiplier": float(radius_multiplier),
        "source_query_nanees": float(np.mean(pooled * pooled)),
        "source_query_coverage": float(np.mean(pooled <= radius_multiplier)),
        "mean_calibration_query_width": float(np.mean(widths)),
    }


def fit_global_calibration(
    source_errors: np.ndarray,
    bank: Mapping[str, Query],
    query_names: Sequence[str],
    model: Any,
    *,
    probability: float,
    minimum_scale: float,
) -> dict[str, float]:
    ratios: list[np.ndarray] = []
    for name in query_names:
        query = bank[name]
        variance = query_variance(model, query.weight)
        error = source_errors @ query.weight
        ratios.append(error * error / variance)
    scale = max(float(np.mean(np.concatenate(ratios))), minimum_scale)
    standardized = []
    for name in query_names:
        query = bank[name]
        variance = scale * query_variance(model, query.weight)
        standardized.append(
            np.abs(source_errors @ query.weight) / math.sqrt(max(variance, _EPS))
        )
    radius = max(float(np.quantile(np.concatenate(standardized), probability)), 1e-8)
    return calibration_record(
        source_errors,
        bank,
        query_names,
        model,
        scale=scale,
        radius_multiplier=radius,
    )


def build_calibrations(
    source_errors: np.ndarray,
    bank: Mapping[str, Query],
    calibration_names: Sequence[str],
    models: Mapping[str, Any],
    *,
    probability: float,
    minimum_scale: float,
) -> tuple[dict[str, dict[str, dict[str, float]]], float]:
    full_fit = fit_global_calibration(
        source_errors,
        bank,
        calibration_names,
        models["full_low_rank"],
        probability=probability,
        minimum_scale=minimum_scale,
    )
    shared: dict[str, dict[str, float]] = {}
    for arm in SHARED_ARMS:
        shared[arm] = calibration_record(
            source_errors,
            bank,
            calibration_names,
            models[arm],
            scale=full_fit["variance_scale"],
            radius_multiplier=full_fit["radius_multiplier"],
        )

    independent = {
        arm: fit_global_calibration(
            source_errors,
            bank,
            calibration_names,
            models[arm],
            probability=probability,
            minimum_scale=minimum_scale,
        )
        for arm in BASE_CALIBRATED_ARMS
    }
    full_width = independent["full_low_rank"]["mean_calibration_query_width"]
    diagonal_width = independent["diagonal_marginal_matched"][
        "mean_calibration_query_width"
    ]
    if diagonal_width <= 0.0:
        raise RuntimeError("diagonal calibration width is nonpositive")
    width_scale_multiplier = (full_width / diagonal_width) ** 2
    diagonal_fit = independent["diagonal_marginal_matched"]
    independent["diagonal_width_matched"] = calibration_record(
        source_errors,
        bank,
        calibration_names,
        models["diagonal_marginal_matched"],
        scale=diagonal_fit["variance_scale"] * width_scale_multiplier,
        radius_multiplier=diagonal_fit["radius_multiplier"],
    )
    matched_width = independent["diagonal_width_matched"][
        "mean_calibration_query_width"
    ]
    width_error = abs(matched_width - full_width)
    independent["diagonal_width_matched"]["source_width_scale_multiplier"] = float(
        width_scale_multiplier
    )
    return {
        "shared_calibration": shared,
        "arm_calibrated": independent,
    }, float(width_error)


def gaussian_cdf(values: np.ndarray) -> np.ndarray:
    flat = np.asarray(values, dtype=np.float64).reshape(-1)
    return np.fromiter(
        (_NORMAL.cdf(float(value)) for value in flat),
        dtype=np.float64,
        count=len(flat),
    ).reshape(np.asarray(values).shape)


def event_probability(
    mean: np.ndarray,
    variance: float,
    threshold: float,
    event: str,
) -> np.ndarray:
    standard_deviation = math.sqrt(max(variance, _EPS))
    if event == "upper":
        return 1.0 - gaussian_cdf((threshold - mean) / standard_deviation)
    if event == "absolute":
        lower = gaussian_cdf((-threshold - mean) / standard_deviation)
        upper = 1.0 - gaussian_cdf((threshold - mean) / standard_deviation)
        return lower + upper
    raise ValueError(f"unsupported event type: {event}")


def event_threshold(
    source_truth: np.ndarray,
    query: Query,
    quantile: float,
) -> tuple[float, float]:
    projected = source_truth @ query.weight
    if query.event == "upper":
        threshold = float(np.quantile(projected, quantile))
        rate = float(np.mean(projected > threshold))
    elif query.event == "absolute":
        threshold = float(np.quantile(np.abs(projected), quantile))
        rate = float(np.mean(np.abs(projected) > threshold))
    else:
        raise ValueError(f"unsupported event: {query.event}")
    return threshold, rate


def query_metrics(
    *,
    target_truth: np.ndarray,
    target_errors: np.ndarray,
    query: Query,
    model: Any,
    calibration: Mapping[str, float],
    threshold: float,
    fallback_cost: float,
    probability_clip: float,
) -> dict[str, float]:
    variance = float(calibration["variance_scale"]) * query_variance(
        model, query.weight
    )
    radius_multiplier = float(calibration["radius_multiplier"])
    truth = target_truth @ query.weight
    error = target_errors @ query.weight
    mean = truth - error
    if query.event == "upper":
        labels = truth > threshold
    elif query.event == "absolute":
        labels = np.abs(truth) > threshold
    else:
        raise ValueError(f"unsupported event: {query.event}")
    probability = np.clip(
        event_probability(mean, variance, threshold, query.event),
        probability_clip,
        1.0 - probability_clip,
    )
    labels_float = labels.astype(np.float64)
    execute = probability <= fallback_cost
    realized_loss = np.where(execute, labels_float, fallback_cost)
    oracle_loss = np.where(labels, fallback_cost, 0.0)
    standardized_square = error * error / max(variance, _EPS)
    radius = radius_multiplier * math.sqrt(max(variance, _EPS))
    accepted = int(np.count_nonzero(execute))
    harmful = int(np.count_nonzero(execute & labels))
    return {
        "target_query_nanees": float(np.mean(standardized_square)),
        "target_90_coverage": float(np.mean(np.abs(error) <= radius)),
        "mean_90_interval_width": float(2.0 * radius),
        "query_nll": float(
            np.mean(
                0.5
                * (
                    math.log(2.0 * math.pi * max(variance, _EPS))
                    + standardized_square
                )
            )
        ),
        "event_brier": float(np.mean(np.square(probability - labels_float))),
        "event_log_loss": float(
            -np.mean(
                labels_float * np.log(probability)
                + (1.0 - labels_float) * np.log1p(-probability)
            )
        ),
        "decision_loss": float(np.mean(realized_loss)),
        "decision_regret": float(np.mean(realized_loss - oracle_loss)),
        "acceptance_fraction": float(np.mean(execute)),
        "harmful_accept_fraction_all": float(harmful / len(labels)),
        "harmful_accept_rate_given_accept": float(
            harmful / accepted if accepted else 0.0
        ),
    }


def summarize_query_metrics(values: Sequence[Mapping[str, float]]) -> dict[str, float]:
    return {
        metric: float(np.mean([float(value[metric]) for value in values]))
        for metric in METRICS
    }


def bootstrap_interval(values: np.ndarray, repetitions: int, seed: int) -> list[float]:
    vector = np.asarray(values, dtype=np.float64)
    if len(vector) == 1:
        return [float(vector[0]), float(vector[0])]
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, len(vector), size=(repetitions, len(vector)))
    means = vector[indices].mean(axis=1)
    return [float(value) for value in np.quantile(means, [0.025, 0.975])]


def paired_summary(
    rows: Sequence[Mapping[str, Any]],
    regime: str,
    comparator: str,
    metric: str,
    *,
    repetitions: int,
    seed: int,
) -> dict[str, Any]:
    differences = np.asarray(
        [
            float(row["regime_summary"][regime]["full_low_rank"][metric])
            - float(row["regime_summary"][regime][comparator][metric])
            for row in rows
        ],
        dtype=np.float64,
    )
    return {
        "metric": metric,
        "comparator": comparator,
        "mean_difference": float(np.mean(differences)),
        "median_difference": float(np.median(differences)),
        "object_bootstrap_95_interval": bootstrap_interval(
            differences, repetitions, seed
        ),
        "object_wins": int(np.count_nonzero(differences < 0.0)),
        "object_ties": int(np.count_nonzero(differences == 0.0)),
        "object_losses": int(np.count_nonzero(differences > 0.0)),
        "worst_object_difference": float(np.max(differences)),
    }


def aggregate(
    rows: Sequence[Mapping[str, Any]], protocol: Mapping[str, Any]
) -> tuple[dict[str, Any], dict[str, Any]]:
    evaluation = require_mapping(protocol["evaluation"], "evaluation")
    repetitions = int(evaluation["bootstrap_repetitions"])
    seed = int(evaluation["bootstrap_seed"])
    arm_summary: dict[str, Any] = {}
    comparisons: dict[str, Any] = {}
    seed_offset = 0
    for regime, arms in REGIMES.items():
        arm_summary[regime] = {
            arm: {
                metric: float(
                    np.mean(
                        [row["regime_summary"][regime][arm][metric] for row in rows]
                    )
                )
                for metric in METRICS
            }
            for arm in arms
        }
        comparisons[regime] = {}
        for comparator in arms[1:]:
            comparisons[regime][comparator] = {}
            for metric in COMPARISON_METRICS:
                comparisons[regime][comparator][metric] = paired_summary(
                    rows,
                    regime,
                    comparator,
                    metric,
                    repetitions=repetitions,
                    seed=seed + seed_offset,
                )
                seed_offset += 1

    def significant(regime: str, comparator: str, metric: str) -> bool:
        value = comparisons[regime][comparator][metric]
        return bool(
            value["mean_difference"] < 0.0
            and value["object_bootstrap_95_interval"][1] < 0.0
        )

    marginal_max = float(max(row["raw_marginal_parity_max_abs"] for row in rows))
    width_error = float(max(row["source_width_match_abs_error"] for row in rows))
    query_split_exact = all(
        len(row["calibration_query_names"]) == 32
        and len(row["evaluation_query_names"]) == 32
        and not (
            set(row["calibration_query_names"])
            & set(row["evaluation_query_names"])
        )
        for row in rows
    )
    gates = {
        "complete_92_object_roster": len(rows) == 92,
        "exact_parent_point_result_reproduced": all(
            bool(row["parent_point_result_exact"]) for row in rows
        ),
        "same_mean_by_construction": all(
            bool(row["same_mean_by_construction"]) for row in rows
        ),
        "shared_raw_coordinate_marginals_match": marginal_max
        <= float(evaluation["marginal_parity_tolerance"]),
        "exact_32_32_query_split": query_split_exact,
        "source_width_match_exact": width_error
        <= float(evaluation["width_match_tolerance"]),
        "shared_full_decision_better_than_diagonal": significant(
            "shared_calibration", "diagonal_marginal_matched", "decision_loss"
        ),
        "shared_full_brier_better_than_diagonal": significant(
            "shared_calibration", "diagonal_marginal_matched", "event_brier"
        ),
        "shared_full_decision_better_than_scrambled": significant(
            "shared_calibration", "scrambled_marginal_matched", "decision_loss"
        ),
        "shared_full_brier_better_than_scrambled": significant(
            "shared_calibration", "scrambled_marginal_matched", "event_brier"
        ),
        "calibrated_full_decision_better_than_diagonal": significant(
            "arm_calibrated", "diagonal_marginal_matched", "decision_loss"
        ),
        "calibrated_full_brier_better_than_diagonal": significant(
            "arm_calibrated", "diagonal_marginal_matched", "event_brier"
        ),
        "calibrated_full_decision_better_than_scrambled": significant(
            "arm_calibrated", "scrambled_marginal_matched", "decision_loss"
        ),
        "calibrated_full_brier_better_than_scrambled": significant(
            "arm_calibrated", "scrambled_marginal_matched", "event_brier"
        ),
        "full_decision_better_than_width_matched_diagonal": significant(
            "arm_calibrated", "diagonal_width_matched", "decision_loss"
        ),
        "full_brier_better_than_width_matched_diagonal": significant(
            "arm_calibrated", "diagonal_width_matched", "event_brier"
        ),
        "full_decision_better_than_local_diagonal_only": significant(
            "arm_calibrated", "local_diagonal_only", "decision_loss"
        ),
        "full_brier_better_than_local_diagonal_only": significant(
            "arm_calibrated", "local_diagonal_only", "event_brier"
        ),
    }
    decision = {
        "gates": gates,
        "strict_shared_dependence_supported": all(
            gates[name]
            for name in (
                "shared_full_decision_better_than_diagonal",
                "shared_full_brier_better_than_diagonal",
                "shared_full_decision_better_than_scrambled",
                "shared_full_brier_better_than_scrambled",
            )
        ),
        "independent_calibration_robustness_supported": all(
            gates[name]
            for name in (
                "calibrated_full_decision_better_than_diagonal",
                "calibrated_full_brier_better_than_diagonal",
                "calibrated_full_decision_better_than_scrambled",
                "calibrated_full_brier_better_than_scrambled",
            )
        ),
        "width_robustness_supported": (
            gates["full_decision_better_than_width_matched_diagonal"]
            and gates["full_brier_better_than_width_matched_diagonal"]
        ),
        "low_rank_component_value_supported": (
            gates["full_decision_better_than_local_diagonal_only"]
            and gates["full_brier_better_than_local_diagonal_only"]
        ),
        "paper_claim_authorized": False,
        "fresh_confirmation_authorized": False,
        "deployment_claim_authorized": False,
    }
    summary = {
        "object_count": len(rows),
        "query_count": 64,
        "calibration_query_count": 32,
        "evaluation_query_count": 32,
        "raw_coordinate_marginal_parity_max_abs": marginal_max,
        "source_width_match_max_abs_error": width_error,
        "arm_summary": arm_summary,
        "comparisons": comparisons,
    }
    return summary, decision


def point_projection(row: Mapping[str, Any]) -> dict[str, Any]:
    keys = (
        "source_fit_id",
        "target_episode_id",
        "forecast_window_count",
        "pooled_field_dimension",
        "candidate_names",
        "candidate_families",
        "candidate_weights",
        "selected_state_ridge",
        "selected_state_kernel",
        "selected_action_ridge",
        "selected_action_kernel",
        "source_cv_active_rmse",
        "guard_accepts",
        "fallback_method",
        "metrics",
        "uncertainty",
    )
    return {key: row[key] for key in keys}


def run(
    *,
    protocol_path: Path,
    recovery_runner_path: Path,
    original_v6_runner_path: Path,
    original_v6_protocol_path: Path,
    parent_protocol_path: Path,
    parent_result_path: Path,
    readiness_path: Path,
    data_root: Path,
    recovery_root: Path,
    original_v6_root: Path,
    parent_control_root: Path,
    frozen_root: Path,
) -> dict[str, Any]:
    protocol = read_json(protocol_path)
    data_root = data_root.resolve(strict=True)
    recovery_root = recovery_root.resolve(strict=True)
    original_v6_root = original_v6_root.resolve(strict=True)
    parent_control_root = parent_control_root.resolve(strict=True)
    frozen_root = frozen_root.resolve(strict=True)
    validate_protocol(
        protocol,
        data_root=data_root,
        recovery_root=recovery_root,
        original_v6_root=original_v6_root,
        parent_control_root=parent_control_root,
        frozen_root=frozen_root,
    )

    recovery = load_module(
        recovery_runner_path.resolve(strict=True),
        "deform360_bound_carrier_recovery_for_v7",
    )
    v6 = load_module(
        original_v6_runner_path.resolve(strict=True),
        "deform360_dependence_query_v6_for_v7",
    )
    v6_protocol = v6.read_json(original_v6_protocol_path)
    parent_protocol = v6.read_json(parent_protocol_path)
    parent_result = v6.read_json(parent_result_path)
    v6.validate_protocol(
        v6_protocol,
        parent_control_root=parent_control_root,
        parent_protocol_path=parent_protocol_path,
        data_root=data_root,
    )
    parent_by_object = v6.validate_parent_result(
        parent_result,
        v6_protocol,
        parent_result_path,
    )

    parent_binding = v6_protocol["parent_confirmation"]
    v5_path = parent_control_root / str(parent_binding["runner_path"])
    v5 = v6.load_module(v5_path, "deform360_v5_parent_for_v7")
    manifest = v5.verify_readiness(
        v6.read_json(readiness_path),
        parent_protocol,
        readiness_path,
    )
    v3, development, base_protocol = v5.validate_frozen_method(
        frozen_root,
        parent_protocol,
    )
    audit_path = parent_control_root / str(parent_binding["audit_path"])
    audit = v6.load_module(audit_path, "deform360_v5_audit_for_v7")
    minimum_episodes = int(
        parent_protocol["selection"]["minimum_complete_episodes_per_object"]
    )

    transfer = require_mapping(protocol["query_transfer"], "query_transfer")
    calibration_config = require_mapping(protocol["calibration"], "calibration")
    evaluation = require_mapping(protocol["evaluation"], "evaluation")
    point_rng = np.random.default_rng(int(development["statistics"]["random_seed"]))
    rows: list[dict[str, Any]] = []
    carrier_drift: list[dict[str, Any]] = []

    for index, expected_value in enumerate(manifest, start=1):
        expected = require_mapping(expected_value, "readiness manifest row")
        object_id = str(expected["object_id"])
        print(
            f"[{index}/{len(manifest)}] held-out-query Bayesian-value evaluation "
            f"{object_id}",
            flush=True,
        )
        parent_row = require_mapping(parent_by_object[object_id], "parent object row")
        descriptors, drift = recovery.build_bound_descriptors(
            v3=v3,
            v5=v5,
            audit=audit,
            data_root=data_root,
            expected=expected,
            parent_row=parent_row,
            minimum_episodes=minimum_episodes,
        )
        carrier_drift.append(dict(drift))

        point_row, capture, source_truth, target_truth = v6.evaluate_object_with_capture(
            v3,
            descriptors,
            development,
            base_protocol,
            point_rng,
        )
        exact_point = point_projection(point_row) == point_projection(parent_row)
        if not exact_point:
            raise RuntimeError(
                f"exact frozen point result did not reproduce: {object_id}"
            )
        source_errors = np.asarray(capture.source_residuals, dtype=np.float64)
        source_errors = source_errors - source_errors.mean(axis=0, keepdims=True)
        target_errors = np.asarray(capture.target_errors, dtype=np.float64)
        predicted_mean = np.asarray(target_truth, dtype=np.float64) - target_errors
        models = build_covariance_models(
            v3.base,
            capture.covariance,
            seed=v6.stable_seed(
                int(transfer["split_seed"]), object_id, "v7-scrambled-factor"
            ),
        )
        reference_marginal = marginal_variance(models["full_low_rank"])
        marginal_parity = float(
            max(
                np.max(np.abs(marginal_variance(models[arm]) - reference_marginal))
                for arm in SHARED_ARMS
            )
        )
        bank = build_query_bank(
            target_truth.shape[1], int(transfer["query_count"])
        )
        calibration_names, evaluation_names = split_query_names(
            bank,
            int(transfer["calibration_query_count"]),
            int(transfer["split_seed"]),
        )
        calibrations, width_error = build_calibrations(
            source_errors,
            bank,
            calibration_names,
            models,
            probability=float(calibration_config["coverage_probability"]),
            minimum_scale=float(calibration_config["minimum_variance_scale"]),
        )

        thresholds = {
            name: event_threshold(
                np.asarray(source_truth, dtype=np.float64),
                bank[name],
                float(evaluation["event_threshold_quantile"]),
            )
            for name in evaluation_names
        }
        query_results: dict[str, Any] = {}
        regime_values: dict[str, dict[str, list[dict[str, float]]]] = {
            regime: {arm: [] for arm in arms}
            for regime, arms in REGIMES.items()
        }
        for name in evaluation_names:
            query = bank[name]
            threshold, source_event_rate = thresholds[name]
            record: dict[str, Any] = {
                "name": name,
                "sensor_mode": query.sensor_mode,
                "row_mode": query.row_mode,
                "column_mode": query.column_mode,
                "event": query.event,
                "weight_sha256": array_digest(query.weight),
                "event_threshold": threshold,
                "source_event_rate": source_event_rate,
                "regimes": {},
            }
            for regime, arms in REGIMES.items():
                record["regimes"][regime] = {}
                for arm in arms:
                    model_name = (
                        "diagonal_marginal_matched"
                        if arm == "diagonal_width_matched"
                        else arm
                    )
                    metrics = query_metrics(
                        target_truth=np.asarray(target_truth, dtype=np.float64),
                        target_errors=target_errors,
                        query=query,
                        model=models[model_name],
                        calibration=calibrations[regime][arm],
                        threshold=threshold,
                        fallback_cost=float(evaluation["fallback_cost"]),
                        probability_clip=float(evaluation["probability_clip"]),
                    )
                    record["regimes"][regime][arm] = metrics
                    regime_values[regime][arm].append(metrics)
            query_results[name] = record

        regime_summary = {
            regime: {
                arm: summarize_query_metrics(regime_values[regime][arm])
                for arm in arms
            }
            for regime, arms in REGIMES.items()
        }
        query_manifest = [
            {
                "name": query.name,
                "sensor_mode": query.sensor_mode,
                "row_mode": query.row_mode,
                "column_mode": query.column_mode,
                "event": query.event,
                "weight_sha256": array_digest(query.weight),
            }
            for query in bank.values()
        ]
        rows.append(
            {
                "object_id": object_id,
                "source_episode_ids": point_row["source_episode_ids"],
                "target_episode_id": point_row["target_episode_id"],
                "target_action": point_row["target_action"],
                "target_action_family": point_row["target_action_family"],
                "dimension": int(target_truth.shape[1]),
                "window_count": int(target_truth.shape[0]),
                "predictive_mean_sha256": array_digest(predicted_mean),
                "same_mean_by_construction": True,
                "parent_point_result_exact": exact_point,
                "raw_marginal_parity_max_abs": marginal_parity,
                "source_width_match_abs_error": width_error,
                "query_manifest_sha256": canonical_digest(query_manifest),
                "calibration_query_names": calibration_names,
                "evaluation_query_names": evaluation_names,
                "calibration_query_set_sha256": canonical_digest(calibration_names),
                "evaluation_query_set_sha256": canonical_digest(evaluation_names),
                "calibrations": calibrations,
                "regime_summary": regime_summary,
                "queries": query_results,
                "bound_carrier_recovery": drift,
            }
        )

    summary, decision = aggregate(rows, protocol)
    drift_summary = {
        "object_count": len(carrier_drift),
        "all_bound_numeric_fingerprints_equal": all(
            bool(row["bound_numeric_fingerprints_equal"]) for row in carrier_drift
        ),
        "all_bound_episode_actions_equal": all(
            bool(row["bound_episode_actions_equal"]) for row in carrier_drift
        ),
        "objects_with_extra_complete_episodes": [
            row["object_id"]
            for row in carrier_drift
            if row["extra_complete_episode_ids"]
        ],
        "unbound_numeric_payloads_opened": False,
        "carrier_drift_sha256": canonical_digest(carrier_drift),
    }
    result: dict[str, Any] = {
        "schema": SCHEMA,
        "schema_version": 7,
        "status": "complete",
        "protocol_id": protocol["protocol_id"],
        "github_sha": os.environ.get("GITHUB_SHA"),
        "runner_name": os.environ.get("RUNNER_NAME"),
        "dataset_root": str(data_root),
        "lineage": protocol["lineage"],
        "carrier_drift_summary": drift_summary,
        "information_boundary": {
            "retrospective_target_reuse": True,
            "exact_frozen_v3_point_predictor_reused": True,
            "exact_parent_point_result_reproduced": all(
                row["parent_point_result_exact"] for row in rows
            ),
            "exact_parent_bound_numeric_carriers_reused": True,
            "live_unbound_numeric_payloads_opened": False,
            "same_predictive_mean_across_every_arm": True,
            "shared_regime_raw_coordinate_marginals_equal": True,
            "shared_regime_scale_and_radius_equal": True,
            "calibration_queries_disjoint_from_evaluation_queries": True,
            "all_uncertainty_calibration_source_only": True,
            "width_matching_source_only": True,
            "target_outcomes_used_for_query_or_arm_selection": False,
            "camera_pixels_opened": False,
            "geometry_or_point_cloud_opened": False,
            "new_measurements_collected": False,
        },
        "summary": summary,
        "decision": decision,
        "objects": rows,
        "carrier_drift": carrier_drift,
        "protocol": protocol,
    }
    result["result_sha256"] = canonical_digest(result)
    return result


def make_report(result: Mapping[str, Any]) -> str:
    summary = result["summary"]
    decision = result["decision"]
    lines = [
        "# Deform360 held-out-query Bayesian-value study v7",
        "",
        f"- Objects: **{summary['object_count']}**",
        f"- Query split: **{summary['calibration_query_count']} source-calibration / "
        f"{summary['evaluation_query_count']} held-out evaluation queries**",
        "- Point predictor: **exact frozen v3**",
        "- New physical measurements: **none**",
        "- Target status: **retrospective reuse of already opened episodes**",
        "- Strict shared-calibration dependence supported: "
        f"**{str(decision['strict_shared_dependence_supported']).lower()}**",
        "- Independent-calibration robustness supported: "
        f"**{str(decision['independent_calibration_robustness_supported']).lower()}**",
        "- Width robustness supported: "
        f"**{str(decision['width_robustness_supported']).lower()}**",
        "- Low-rank component value supported: "
        f"**{str(decision['low_rank_component_value_supported']).lower()}**",
        "",
    ]
    for regime, arms in REGIMES.items():
        lines.extend(
            [
                f"## {regime.replace('_', ' ').title()}",
                "",
                "| Arm | nANEES | 90% coverage | Width | NLL | Brier | Decision loss | Acceptance |",
                "|---|---:|---:|---:|---:|---:|---:|---:|",
            ]
        )
        for arm in arms:
            values = summary["arm_summary"][regime][arm]
            lines.append(
                f"| `{arm}` | {values['target_query_nanees']:.6g} | "
                f"{values['target_90_coverage']:.3%} | "
                f"{values['mean_90_interval_width']:.6g} | "
                f"{values['query_nll']:.6g} | {values['event_brier']:.6g} | "
                f"{values['decision_loss']:.6g} | "
                f"{values['acceptance_fraction']:.3%} |"
            )
        lines.extend(
            [
                "",
                "Negative paired differences favor `full_low_rank`.",
                "",
                "| Comparator | Metric | Difference | 95% object bootstrap | W/T/L |",
                "|---|---|---:|---:|---:|",
            ]
        )
        for comparator, metrics in summary["comparisons"][regime].items():
            for metric, values in metrics.items():
                interval = values["object_bootstrap_95_interval"]
                lines.append(
                    f"| `{comparator}` | `{metric}` | "
                    f"{values['mean_difference']:.6g} | "
                    f"[{interval[0]:.6g}, {interval[1]:.6g}] | "
                    f"{values['object_wins']}/{values['object_ties']}/"
                    f"{values['object_losses']} |"
                )
        lines.append("")
    lines.extend(
        [
            "## Registered gates",
            "",
            "| Gate | Passed |",
            "|---|---:|",
        ]
    )
    for name, passed in decision["gates"].items():
        lines.append(f"| `{name}` | {str(bool(passed)).lower()} |")
    lines.extend(
        [
            "",
            "Workflow success records technical completion, not a positive scientific",
            "outcome. The protocol does not authorize a paper, calibration, transfer,",
            "deployment, or safety claim.",
            "",
        ]
    )
    return "\n".join(lines)


def write_object_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    fields = [
        "object_id",
        "target_episode_id",
        "target_action_family",
        "dimension",
        "window_count",
        "parent_point_result_exact",
        "raw_marginal_parity_max_abs",
        "source_width_match_abs_error",
    ]
    for regime, arms in REGIMES.items():
        for arm in arms:
            for metric in METRICS:
                fields.append(f"{regime}_{arm}_{metric}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            output = {name: row[name] for name in fields[:8]}
            for regime, arms in REGIMES.items():
                for arm in arms:
                    for metric in METRICS:
                        output[f"{regime}_{arm}_{metric}"] = row["regime_summary"][
                            regime
                        ][arm][metric]
            writer.writerow(output)


@dataclass
class _DummyCovarianceModel:
    mean_error: np.ndarray
    diagonal: np.ndarray
    factor: np.ndarray
    multiplier: float
    marginal_z: float
    source_marginal_coverage: float
    source_joint_nanees: float


class _DummyBase:
    CovarianceModel = _DummyCovarianceModel


def self_test() -> None:
    rng = np.random.default_rng(7)
    dimension = 4 * FIELD_DIMENSION_PER_SENSOR
    bank = build_query_bank(dimension, 64)
    calibration_names, evaluation_names = split_query_names(bank, 32, 260903)
    assert len(calibration_names) == len(evaluation_names) == 32
    assert not (set(calibration_names) & set(evaluation_names))
    diagonal = np.full(dimension, 0.4)
    factor = rng.normal(scale=0.03, size=(dimension, 5))
    covariance = _DummyCovarianceModel(
        np.zeros(dimension), diagonal, factor, 1.3, 1.64, 0.9, 1.0
    )
    models = build_covariance_models(_DummyBase, covariance, seed=11)
    reference = marginal_variance(models["full_low_rank"])
    for arm in SHARED_ARMS:
        assert np.allclose(marginal_variance(models[arm]), reference)
    source_errors = rng.normal(size=(40, dimension))
    calibrations, width_error = build_calibrations(
        source_errors,
        bank,
        calibration_names,
        models,
        probability=0.9,
        minimum_scale=1e-8,
    )
    assert width_error <= 1e-12
    assert math.isclose(
        calibrations["arm_calibrated"]["full_low_rank"][
            "mean_calibration_query_width"
        ],
        calibrations["arm_calibrated"]["diagonal_width_matched"][
            "mean_calibration_query_width"
        ],
        rel_tol=0.0,
        abs_tol=1e-12,
    )
    query = bank[evaluation_names[0]]
    truth = rng.normal(size=(12, dimension))
    error = rng.normal(scale=0.2, size=(12, dimension))
    threshold, _ = event_threshold(truth, query, 0.9)
    metrics = query_metrics(
        target_truth=truth,
        target_errors=error,
        query=query,
        model=models["full_low_rank"],
        calibration=calibrations["shared_calibration"]["full_low_rank"],
        threshold=threshold,
        fallback_cost=0.1,
        probability_clip=1e-9,
    )
    assert set(metrics) == set(METRICS)
    assert all(math.isfinite(value) for value in metrics.values())
    print("deform360 held-out-query v7 self-test passed")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--protocol", type=Path)
    parser.add_argument("--recovery-runner", type=Path)
    parser.add_argument("--original-v6-runner", type=Path)
    parser.add_argument("--original-v6-protocol", type=Path)
    parser.add_argument("--parent-protocol", type=Path)
    parser.add_argument("--parent-result", type=Path)
    parser.add_argument("--readiness-json", type=Path)
    parser.add_argument("--data-root", type=Path)
    parser.add_argument("--recovery-root", type=Path)
    parser.add_argument("--original-v6-root", type=Path)
    parser.add_argument("--parent-control-root", type=Path)
    parser.add_argument("--frozen-root", type=Path)
    parser.add_argument("--output-json", type=Path)
    parser.add_argument("--output-report", type=Path)
    parser.add_argument("--output-csv", type=Path)
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return 0
    required = (
        "protocol",
        "recovery_runner",
        "original_v6_runner",
        "original_v6_protocol",
        "parent_protocol",
        "parent_result",
        "readiness_json",
        "data_root",
        "recovery_root",
        "original_v6_root",
        "parent_control_root",
        "frozen_root",
        "output_json",
        "output_report",
        "output_csv",
    )
    missing = [name for name in required if getattr(args, name) is None]
    if missing:
        parser.error(f"missing required arguments: {', '.join(missing)}")
    result = run(
        protocol_path=args.protocol,
        recovery_runner_path=args.recovery_runner,
        original_v6_runner_path=args.original_v6_runner,
        original_v6_protocol_path=args.original_v6_protocol,
        parent_protocol_path=args.parent_protocol,
        parent_result_path=args.parent_result,
        readiness_path=args.readiness_json,
        data_root=args.data_root,
        recovery_root=args.recovery_root,
        original_v6_root=args.original_v6_root,
        parent_control_root=args.parent_control_root,
        frozen_root=args.frozen_root,
    )
    write_json(args.output_json, result)
    args.output_report.parent.mkdir(parents=True, exist_ok=True)
    args.output_report.write_text(make_report(result), encoding="utf-8")
    write_object_csv(args.output_csv, result["objects"])
    print(json.dumps(result["summary"], indent=2, sort_keys=True), flush=True)
    print(json.dumps(result["decision"], indent=2, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
